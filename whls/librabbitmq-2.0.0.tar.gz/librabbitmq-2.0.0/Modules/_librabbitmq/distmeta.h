#define PYRABBITMQ_VERSION "2.0.0"
#define PYRABBITMQ_AUTHOR "Ask Solem"
#define PYRABBITMQ_CONTACT "ask@celeryproject.org"
#define PYRABBITMQ_HOMEPAGE "http://github.com/celery/librabbitmq"
